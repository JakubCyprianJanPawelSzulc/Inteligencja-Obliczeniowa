import gymnasium as gym
import numpy
import pygad
from bestSolution1 import run_solution

env = gym.make("LunarLander-v2")


observation, info = env.reset(seed=2137)


def run_solution(solution):
    reward = 0
    for step in solution:
        observation, reward, terminated, truncated, info = env.step(int(step))
        if terminated or truncated:
            break
    env.reset(seed=2137)
    return reward

def fitness_func(solution, solution_idx):
    return run_solution(solution)


fitness_function = fitness_func

num_generations = 60
num_parents_mating = 15

sol_per_pop = 70
num_genes = 100

parent_selection_type = "sss"
keep_parents = 10

crossover_type = "single_point"

mutation_type = "random"
mutation_percent_genes = 10

ga_instance = pygad.GA(num_generations=num_generations,
                       num_parents_mating=num_parents_mating,
                       fitness_func=fitness_function,
                       sol_per_pop=sol_per_pop,
                       num_genes=num_genes,
                       gene_space=[0,1,2,3],
                       parent_selection_type=parent_selection_type,
                       keep_parents=keep_parents,
                       crossover_type=crossover_type,
                       mutation_type=mutation_type,
                       mutation_percent_genes=mutation_percent_genes)

ga_instance.run()

solution, solution_fitness, solution_idx = ga_instance.best_solution()
print("Parametry najlepszego rozwiązania : {solution}".format(solution=solution))
print("Fitness = {solution_fitness}".format(solution_fitness=solution_fitness))

env.close()
